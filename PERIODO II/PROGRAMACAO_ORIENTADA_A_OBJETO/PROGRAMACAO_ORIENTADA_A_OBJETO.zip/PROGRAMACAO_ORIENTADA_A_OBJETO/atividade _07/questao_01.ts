class Veiculo {
    placa?: String;
    ano?: number;
    modelo?: String;
}

class Carro extends Veiculo{

}

class CarroEletrico extends Veiculo{
    autonomiaBateria?: number;
}





