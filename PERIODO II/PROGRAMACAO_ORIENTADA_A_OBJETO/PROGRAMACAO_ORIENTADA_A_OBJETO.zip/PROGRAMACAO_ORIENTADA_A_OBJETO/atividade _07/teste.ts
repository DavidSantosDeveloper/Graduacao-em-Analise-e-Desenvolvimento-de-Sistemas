let data1=new Date(2023,1,1,5,10,15,0)
console.log(data1)
console.log(`${data1.getFullYear()}/${data1.getMonth()}/${data1.getDate()}  - ${data1.getHours()} - ${data1.getMinutes()} - ${data1.getSeconds()}`)



