"use strict";
class Radio {
    constructor(volume) {
        this.volume = volume;
    }
}
let r = new Radio();
r.volume = 10;
