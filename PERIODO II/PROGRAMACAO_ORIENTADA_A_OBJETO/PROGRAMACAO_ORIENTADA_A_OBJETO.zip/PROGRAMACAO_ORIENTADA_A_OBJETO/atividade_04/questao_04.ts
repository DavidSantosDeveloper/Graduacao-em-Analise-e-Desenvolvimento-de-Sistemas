class Radio {
    volume : number;
    constructor(volume : number) {
    this.volume = volume;
    
    }
}

let r : Radio = new Radio();
r.volume = 10;