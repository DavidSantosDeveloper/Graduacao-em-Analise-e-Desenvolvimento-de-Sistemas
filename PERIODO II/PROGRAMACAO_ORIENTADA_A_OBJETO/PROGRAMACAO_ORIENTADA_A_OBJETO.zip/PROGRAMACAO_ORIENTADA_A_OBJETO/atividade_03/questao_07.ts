/* 

    7. Converta em arrow function a seguinte função:

    function ola() {
        console.log("Olá");
    }

    let ola=function (){
        console.log("Olá");
    }
    ola()

*/

let ola=()=>console.log("Ola")
ola()


