function verificar_se_eh_par(numero:number):boolean{
    if(numero%2==0){
        return true
    }
    else{
        return false
    }
}
