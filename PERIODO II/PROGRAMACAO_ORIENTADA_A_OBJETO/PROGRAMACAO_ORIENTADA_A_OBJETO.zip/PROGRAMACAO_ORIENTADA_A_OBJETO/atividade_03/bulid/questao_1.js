"use strict";
function verificar_se_eh_par(numero) {
    if (numero % 2 == 0) {
        return true;
    }
    else {
        return false;
    }
}
