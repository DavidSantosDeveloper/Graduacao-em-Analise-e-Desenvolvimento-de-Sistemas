# ProvaDisciplinaPOO_2023_2
1.Ana Beatriz Brito de Farias
2.Francisco David Santos Sousa

