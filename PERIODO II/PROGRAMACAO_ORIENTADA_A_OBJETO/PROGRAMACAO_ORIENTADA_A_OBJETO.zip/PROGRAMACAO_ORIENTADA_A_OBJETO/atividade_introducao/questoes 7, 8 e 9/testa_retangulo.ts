import {Retangulo} from "./Retangulo.js";



let retangulo:Retangulo=new Retangulo();
retangulo.lado1=30
retangulo.lado2=40

console.log(retangulo.calcularArea())
console.log(retangulo.calcularPerimetro())
