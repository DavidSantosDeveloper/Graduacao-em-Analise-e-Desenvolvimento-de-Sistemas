function main(){

    let nome: string="Ely"
    let time: number=120.56
    let linguagem_de_programacao:string="TypeScript"

    console.log(`${nome}
    My payment time is ${time}
    and
    my preffered language is ${linguagem_de_programacao}
    `)
}


main()