/*
   noImplicitAny
*/

export function fn(s) {
    // No error?
    console.log(s.subtr(3));
  }
  fn(42);