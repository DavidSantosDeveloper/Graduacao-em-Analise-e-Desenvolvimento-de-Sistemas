/*
Separei cada configuracao em um arquivo:

#

 allowUnreachableCode com valor true   --> config_b.ts;

 noImplicitAny com valor true -->config_c.ts;

d. target com o valor ES3 -->config_d.ts;
e. strictNullChecks para false   -->config_e.ts;


*/