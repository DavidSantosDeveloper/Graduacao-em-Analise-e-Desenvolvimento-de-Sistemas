/*
   target com o valor ES3.
*/


function soma(numero1:number,numero2:number):number{
    return numero1+numero2
}
soma(1,2)