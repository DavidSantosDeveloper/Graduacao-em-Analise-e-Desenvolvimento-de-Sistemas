1. No terminal:
>>   npm install prompt-sync
2. No terminal:
>>   npm init es6

3. Na classe App insira o import a seguir
##   import prompt from "prompt-sync";

3.NO ARQUIVO tsconfig.json
## na opcao "module:" coloque o valor "NodeNext"

4.No terminal:
>>  npm i --save-dev @types/prompt-sync
